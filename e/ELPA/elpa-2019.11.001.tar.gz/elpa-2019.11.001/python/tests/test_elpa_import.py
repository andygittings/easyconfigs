def test_pyelpa_import():
    import pyelpa

def test_elpa_supported_api_version():
    from pyelpa import Elpa
    e = Elpa()
