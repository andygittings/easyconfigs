/****************************************************************************
**  LinkTest                                                               **
*****************************************************************************
**  Copyright (c) 2008-2011                                                **
**  Forschungszentrum Juelich, Juelich Supercomputing Centre               **
**                                                                         **
**  See the file COPYRIGHT in the package base directory for details       **
****************************************************************************/
#ifndef MPILINKTEST_DATASTRUCTURES_MPI_H
#define MPILINKTEST_DATASTRUCTURES_MPI_H

#include "mpilinktest_datastructures.h"
int              _linktest_distribute_spec_mpi( _linktest_spec *linktest_spec );

#endif
