#ifndef SION_CXX_OMPI_HPP_
#define SION_CXX_OMPI_HPP_

#endif
