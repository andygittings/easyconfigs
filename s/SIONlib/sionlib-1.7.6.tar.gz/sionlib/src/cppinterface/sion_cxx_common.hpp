#ifndef SION_CXX_COMMON_HPP_
#define SION_CXX_COMMON_HPP_

//#include "sion_common.h"
#include "sion.h"
#include <string>
#include <string.h>
#include "sion_cxx_base.hpp"

#endif /* SION_CXX_COMMON_HPP_ */
