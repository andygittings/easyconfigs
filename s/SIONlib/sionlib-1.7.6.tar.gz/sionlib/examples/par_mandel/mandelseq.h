#ifndef MANDELSEQ_H
#define MANDELSEQ_H

#include "infostruct.h"

void print_infostruct(const _infostruct* info);

#endif
